package com.utad.inso.proyecto_final;

public class DesertAbstractFactory implements EnemyAbstractFactory {

    public IceSoldier createIceSoldier() {
        return new DesertIceSoldier();
    }

    public InfernalDragon createInfernalDragon() {
        return new DesertInfernalDragon();
    }
    public SandGiant createSandGiant() {
        return new DesertSandGiant();
    }
}
