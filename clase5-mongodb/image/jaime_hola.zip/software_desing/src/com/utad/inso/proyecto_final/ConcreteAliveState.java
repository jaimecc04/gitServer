package com.utad.inso.proyecto_final;

public class ConcreteAliveState implements CharacterState {

    private Character       character;

    ConcreteAliveState(Character character) {
        this.character = character;
    }

    public void process() {
        if(character.getHealth() <= 0) {
            this.die();
        } else {
            this.freeze();
        }
    }

    public void die() {
        character.setState(character.getDeadState());
    }

    public void freeze() {
        character.setState(character.getFrozenState());
        System.out.println("-----> El personaje está congelado");
    }

    public void unfreeze() {
        System.out.println("ERROR - El personaje no está congelado");
    }
}
