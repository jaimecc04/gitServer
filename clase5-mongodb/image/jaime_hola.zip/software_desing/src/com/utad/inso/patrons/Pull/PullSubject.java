package com.utad.inso.patrons.Pull;
/**
 * Interface de un modelo observable que aplica protocolo Pull 
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public interface PullSubject {
	public void attach(PullObserver observer);
	public void detach(PullObserver observer);
	public void notifyObservers();  

}
