package com.utad.inso.patrons.StrategyAreas;

public interface AreaStrategy {
    double area(int x);
}
