package com.utad.inso.patrons.Pull;
/**
 * Observador Pull que muestra un valor en base decimal en base octal
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public class OctIntegerObserver implements PullObserver {

	private ConcreteIntegerSubject		concreteIntegerSubject;
	

	public OctIntegerObserver(ConcreteIntegerSubject concreteIntegerSubject)  {
		super();
		this.concreteIntegerSubject = concreteIntegerSubject;
	}

	public void update() {
		System.out.println( "Octal String: " + 
				Integer.toOctalString( this.concreteIntegerSubject.getState()));
		
	}

}
