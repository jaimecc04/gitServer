package com.utad.inso.patrons.StrategyPattern;

public class MusicTest {
    static void tune(Instrument instrument) {
        instrument.play(Note.DO);

        if(instrument instanceof ElectricSound) {
            ((ElectricSound) instrument).electricPlay(Note.DO);
        }
    }

    static void tuneAll(Instrument[] instruments) {
        for(Instrument i: instruments) {
            tune(i);
        }
    }

    public static void main(String[] args) {
        Instrument[] orchestra = {new Woodwind(), new Brass(), new Percussion(), new Stringed()};
        tuneAll(orchestra);
    }
}
