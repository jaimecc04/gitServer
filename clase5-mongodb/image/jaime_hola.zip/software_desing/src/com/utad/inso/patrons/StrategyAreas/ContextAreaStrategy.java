package com.utad.inso.patrons.StrategyAreas;

public class ContextAreaStrategy {
    private AreaStrategy areaStrategy;

    public ContextAreaStrategy(AreaStrategy areaStrategy) {
        this.areaStrategy = areaStrategy;
    }

    public void setAreaStrategy(AreaStrategy areaStrategy) {
        this.areaStrategy = areaStrategy;
    }

    public double area(int x) {
        return this.areaStrategy.area(x);
    }
}
