package com.utad.inso.proyecto_final;

public class GoldArmorConcreteStrategy implements ArmorAbstractStrategy {

    public Integer getProtection() {
        return 50;
    }
}
