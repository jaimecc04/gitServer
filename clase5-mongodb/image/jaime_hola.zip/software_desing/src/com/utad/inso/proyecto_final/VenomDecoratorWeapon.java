package com.utad.inso.proyecto_final;

public class VenomDecoratorWeapon implements WeaponDecoratorComponent {

    WeaponComponent     decorated;

    public VenomDecoratorWeapon(WeaponComponent decorated) {
        this.decorated = decorated;
    }

    public Double getDamage() {
        return decorated.getDamage() + 60;
    }

    public WeaponComponent getDecorated() {
        return decorated;
    }

    public void setDecorated(WeaponComponent decorated) {
        this.decorated = decorated;
    }

    public String toString() {
        return this.decorated + "con veneno ";
    }
}
