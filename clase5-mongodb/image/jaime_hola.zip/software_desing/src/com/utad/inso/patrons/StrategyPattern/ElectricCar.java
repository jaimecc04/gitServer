package com.utad.inso.patrons.StrategyPattern;

public class ElectricCar {

    private String marca;
    private String modelo;
    private String color;
    private Engine motor;

    ElectricCar(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;

        this.motor = new Engine("Eléctrico");
    }


    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public void encender() {
        this.motor.encender(); // Delegación por composición
    }

    public void avanzar() {
        System.out.println("Avanzando " + this);
    }

    public String toString() {
        return this.getMarca() + " " + this.getModelo() + " " + this.getColor();
    }

    public static void main(String[] args) {
        ElectricCar tesla = new ElectricCar("Tesla", "Model3", "rojo");
        tesla.encender();
        tesla.avanzar();
    }
}
