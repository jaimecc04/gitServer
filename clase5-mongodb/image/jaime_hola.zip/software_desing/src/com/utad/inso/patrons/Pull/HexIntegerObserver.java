package com.utad.inso.patrons.Pull;
/**
 * Observador Pull que muestra un valor en base decimal en base hexadecimal
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public class HexIntegerObserver implements PullObserver {

	private ConcreteIntegerSubject		concreteIntegerSubject;
	
	public HexIntegerObserver(ConcreteIntegerSubject concreteIntegerSubject)  {
		super();
		this.concreteIntegerSubject = concreteIntegerSubject;
	}

	public void update() {
		System.out.println( "Hexadecimal String: " + 
				Integer.toHexString( this.concreteIntegerSubject.getState()));
		
	}

}
