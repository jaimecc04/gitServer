package com.utad.inso.patrons.Pull;

import java.util.ArrayList;
import java.util.List;
/**
 * Modelo observable 'concreto' que aplica protocolo Pull 
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public class ConcreteIntegerSubject implements PullSubject {
	private List<PullObserver> observers;
	private Integer state;

	public ConcreteIntegerSubject() {
		this(0);
	}
	public ConcreteIntegerSubject(Integer state) {
		this(state, new ArrayList<PullObserver>() );
	}

	public ConcreteIntegerSubject(Integer state, List<PullObserver> observers) {
		super();
		this.state = state;
		this.observers = observers;
	}

	public List<PullObserver> getObservers() {
		return observers;
	}
	public void setObservers(List<PullObserver> observers) {
		this.observers = observers;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
		this.notifyObservers();
	}
	
	public void attach(PullObserver observer) {
		this.observers.add(observer);
	}

	public void detach(PullObserver observer) {
		this.observers.remove(observer);
	}

	public void notifyObservers() {
		for (PullObserver observer : this.observers) {
			 observer.update();
		}
	}
}
