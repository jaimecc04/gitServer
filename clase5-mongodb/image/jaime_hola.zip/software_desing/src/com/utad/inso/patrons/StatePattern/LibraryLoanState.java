package com.utad.inso.patrons.StatePattern;

public interface LibraryLoanState {
    void admit(LibraryLoanRequestContext context);
    void recoger(LibraryLoanRequestContext context);
    void devolver(LibraryLoanRequestContext context);
    void rechazar(LibraryLoanRequestContext context);
}
