package com.utad.inso.proyecto_final;

public class FireDecoratorWeapon implements WeaponDecoratorComponent {

    WeaponComponent     decorated;

    public FireDecoratorWeapon(WeaponComponent decorated) {
        this.decorated = decorated;
    }

    public Double getDamage() {
        return decorated.getDamage() + 40;
    }

    public WeaponComponent getDecorated() {
        return decorated;
    }

    public void setDecorated(WeaponComponent decorated) {
        this.decorated = decorated;
    }

    public String toString() {
        return this.decorated + "con fuego ";
    }
}
