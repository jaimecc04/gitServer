package com.utad.inso.patrons.StrategyPattern;

public interface ElectricSound {
    void electricPlay(Note note);
}
