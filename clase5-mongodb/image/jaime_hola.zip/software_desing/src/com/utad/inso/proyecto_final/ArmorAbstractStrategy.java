package com.utad.inso.proyecto_final;

public interface ArmorAbstractStrategy {
    public Integer getProtection();
}
