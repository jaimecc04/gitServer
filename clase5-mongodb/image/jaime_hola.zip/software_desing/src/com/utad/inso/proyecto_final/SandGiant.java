package com.utad.inso.proyecto_final;

public abstract class SandGiant implements Enemy {
    protected Double                      health;
    protected ArmorAbstractStrategy       armor;
    protected WeaponComponent             weapon;
    protected Double                      strength;
    protected Double                      precision;

    protected CharacterState              characterState;
    protected ConcreteAliveState          concreteAliveState;
    protected ConcreteDeadState           concreteDeadState;
    protected ConcreteFrozenState         concreteFrozenState;


    public SandGiant() {
        this.armor = new LeatherArmorConcreteStrategy();
        this.weapon = new KatanaBaseWeapon();
        this.health = Math.round(GameController.getInstance().getRandGenerator().nextDouble(150) * 10.0) / 10.0;
        this.strength = Math.round(GameController.getInstance().getRandGenerator().nextDouble(100) * 10.0) / 10.0;
        this.precision = 300 - this.health - this.strength;


        this.concreteAliveState = new ConcreteAliveState(this);
        this.concreteDeadState = new ConcreteDeadState(this);
        this.concreteFrozenState = new ConcreteFrozenState(this);

        this.characterState = this.concreteAliveState;
    }

    public Double getStrength() {
        return strength;
    }

    public Double getPrecision() {
        return precision;
    }

    public void decideAction() {
        Integer rand_int = GameController.getInstance().getRandGenerator().nextInt(10);

        if(rand_int < 3) {
            if(this.getArmor() instanceof SilverArmorConcreteStrategy) {
                this.setArmor(new NoArmorConcreteStrategy());
                System.out.println("El enemigo se quitó la armadura");
            } else {
                this.setArmor(new SilverArmorConcreteStrategy());
                System.out.println("El enemigo se puso una armadura de plata");
            }
        } else if(rand_int < 5) {
            System.out.println("El ataque del enemigo falló");
        } else {
            this.attack(GameController.getInstance().getPlayer());
        }
    }

}