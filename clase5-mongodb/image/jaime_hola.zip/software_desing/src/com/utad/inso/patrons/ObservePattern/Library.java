package com.utad.inso.patrons.ObservePattern;

public class Library {
    BookAlarm bookAlarm;

    public Library() {
        this.bookAlarm = new BookAlarm();
    }

    public void returnBook(Book book) {
        if (book.getBookState() == BookState.BAD) {
            bookAlarm.setBook(book);
        }
    }
}
