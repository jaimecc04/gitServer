package com.utad.inso.proyecto_final;

public class Test {
    public static void main(String[] args) {
        GameController gameController = GameController.getInstance();
        gameController.start();
    }
}
