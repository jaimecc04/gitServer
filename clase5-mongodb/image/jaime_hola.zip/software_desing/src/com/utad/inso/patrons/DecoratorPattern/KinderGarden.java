package com.utad.inso.patrons.DecoratorPattern;

import java.util.ArrayList;
import java.util.List;

public class KinderGarden {
    private static List<KinderGardenBaby> babies;

    public KinderGarden(){
        this(new ArrayList<KinderGardenBaby>());
    }

    public KinderGarden(List<KinderGardenBaby> babies){
        super();
        this.babies = babies;
    }

    public static List<KinderGardenBaby> getBabies() {
        return babies;
    }

    public void setBabies(List<KinderGardenBaby> babies){
        this.babies = babies;
    }

    public void checkBabies(){
        System.out.print("\nPasamos lista \n");
        for(KinderGardenBaby baby: this.babies){
            System.out.println(baby.getRewardComponent().getDescription());
        }
    }
}
