package com.utad.inso.proyecto_final;

public class HellAbstractFactory implements EnemyAbstractFactory {

    public IceSoldier createIceSoldier() {
        return new HellIceSoldier();
    }

    public InfernalDragon createInfernalDragon() {
        return new HellInfernalDragon();
    }
    public SandGiant createSandGiant() {
        return new HellSandGiant();
    }
}