package com.utad.inso.patrons.StatePattern;

public interface LoanState {
    void admit(LibraryLoanRequestContext context);
    void pickUp(LibraryLoanRequestContext context);
    void returnBook(LibraryLoanRequestContext context);
    void reject(LibraryLoanRequestContext context);
}

