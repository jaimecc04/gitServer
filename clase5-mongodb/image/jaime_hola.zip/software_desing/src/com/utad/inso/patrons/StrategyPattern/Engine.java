package com.utad.inso.patrons.StrategyPattern;

public class Engine {
    private String tipo;
    public static final String TIPO_POR_DEFECTO = "N/A";

    public Engine(String tipo) {
        this.tipo = tipo;
    }

    public Engine() {
        this(Engine.TIPO_POR_DEFECTO);
    }

    public String getTipo() {
        return this.tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void encender() {
        System.out.println(this.tipo + " encendido!");
    }


    public String toString() {
        return this.getClass().getName() + " de tipo " + this.getTipo();
    }

    public static void main(String[] args) {
        Engine engine = new Engine("Eléctrico");
        engine.encender();
        System.out.println(engine.toString());
    }
}
