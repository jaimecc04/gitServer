package com.utad.inso.proyecto_final;

public class GlacialSandGiant extends SandGiant {
    public void attack(Character target) {
        if(this.getState() instanceof ConcreteFrozenState) {
            System.out.println("Gigante de arena glacial está congelado y no puede atacar");
            this.getState().process();
        } else {
            Double dano = AttackCalculator.getInstance().returnAttack(this);
            target.takeDamage(dano);
            System.out.println("Gigante de arena glacial ataca con " + this.getWeapon() + " [-" + dano + "HP]");
        }

    }

    public CharacterState getState() {
        return this.characterState;
    }

    public ConcreteFrozenState getFrozenState() {
        return this.concreteFrozenState;
    }

    public ConcreteAliveState getAliveState() {
        return this.concreteAliveState;
    }

    public ConcreteDeadState getDeadState() {
        return this.concreteDeadState;
    }

    public void setState(CharacterState state) {
        this.characterState = state;
    }

    public void takeDamage(Double damage) {
        this.health -= damage;

        if(this.health <= 0){
            this.characterState.process();
        }
    }

    public WeaponComponent getWeapon() {
        return this.weapon;
    }

    public void setWeapon(WeaponComponent weapon) {
        this.weapon = weapon;
    }

    public ArmorAbstractStrategy getArmor() {
        return this.armor;
    }

    public Double getHealth() {
        return this.health;
    }

    public void setArmor(ArmorAbstractStrategy armor) {
        this.armor = armor;
    }


    public String toString() {
        return "Gigante de arena glacial [" + this.health + "HP]";
    }
}
