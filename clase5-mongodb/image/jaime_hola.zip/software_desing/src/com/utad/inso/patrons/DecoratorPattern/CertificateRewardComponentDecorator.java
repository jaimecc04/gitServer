package com.utad.inso.patrons.DecoratorPattern;

public class CertificateRewardComponentDecorator extends AbstracRewardComponentDecorator {
    public CertificateRewardComponentDecorator(RewardComponent rewardComponent) {
        super(rewardComponent);
    }

    @Override
    public String toString() {
        return " con premio de buena conducta pañal";
    }
}
