package com.utad.inso.proyecto_final;
import java.util.Random;

public class AttackCalculator {
    private static AttackCalculator attackCalculator = new AttackCalculator();

    private  GameController     gameController;
    private AttackCalculator() {
        super();
        this.gameController = GameController.getInstance();
    }

    public void setGameController(GameController gameController) {
        this.gameController = gameController;
    }

    public static AttackCalculator getInstance() {
        return attackCalculator;
    }

    public Double returnAttack(Character character) {

        Double damage = character.getWeapon().getDamage() * (character.getStrength() / 100) - character.getArmor().getProtection();
        Random rand = new Random();

        if(gameController.getCurrentLevel() == Worlds.DESERT) {
            if(character instanceof DesertSandGiant) {
                damage *= 2;
            } else if(character instanceof DesertIceSoldier) {
                damage *= 0.5;
            }
        }

        else if (gameController.getCurrentLevel() == Worlds.GLACIAL) {

            if(rand.nextInt(300) < 300 - character.getPrecision()) {
                damage *= -1;
            }

            if(character instanceof GlacialIceSoldier) {
                damage *= 2;
            } else if(character instanceof GlacialInfernalDragon) {
                damage *= 0.5;
            }
        }

        else {
            if(character instanceof HellInfernalDragon) {
                damage *= 2.5;
            } else {
                damage *= 0.75;
            }
        }


        // ATAQUES CRITICOS

        if(character instanceof Player) {
            if(rand.nextInt(10) < 3) {
                damage *= 2;
            }
        } else if(rand.nextInt(10) == 1) {
                damage *= 2;
        }

        return damage;
    }
}
