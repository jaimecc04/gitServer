package com.utad.inso.patrons.StatePattern;

public class RejectedState implements LoanState {
    @Override
    public void admit(LibraryLoanRequestContext context) {
        System.out.println("La solicitud ya ha sido rechazada");
    }

    @Override
    public void pickUp(LibraryLoanRequestContext context) {
        System.out.println("La solicitud ha sido rechazada");
    }

    @Override
    public void returnBook(LibraryLoanRequestContext context) {
        System.out.println("La solicitud ha sido rechazada");
    }

    @Override
    public void reject(LibraryLoanRequestContext context) {
        System.out.println("La solicitud ya ha sido rechazada");
    }
}
