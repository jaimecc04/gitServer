package com.utad.inso.patrons.Pull;
/**
 * Clase Test Observer pattern con protocolo Pull
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public class PullObserverPatternTest {
	public static void main(String[] args) {

		ConcreteIntegerSubject subject = new ConcreteIntegerSubject();

		PullObserver binaryIntegerObserver = new BinIntegerObserver(subject);
		PullObserver hexaIntegerObserver = new HexIntegerObserver(subject);
		PullObserver octalIntegerObserver = new OctIntegerObserver(subject);

		subject.attach(binaryIntegerObserver);
		subject.attach(hexaIntegerObserver);
		subject.attach(octalIntegerObserver);
		System.out.println("First state value****************");
		System.out.println("state decimal value: 11");
		subject.setState(11);

		System.out.println("Second state value***************");
		System.out.println("State decimal value: 14");
		subject.setState(14);
		
	}
}
