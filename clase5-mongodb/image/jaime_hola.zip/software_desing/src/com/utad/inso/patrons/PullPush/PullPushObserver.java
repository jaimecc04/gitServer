package com.utad.inso.patrons.PullPush;
/**
 * Interface de un observador que aplica protocolo Pull-Push 
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public interface PullPushObserver {
	public void update(PullPushSubject subject,Object object);
}
