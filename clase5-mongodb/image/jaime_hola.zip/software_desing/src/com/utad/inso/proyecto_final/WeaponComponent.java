package com.utad.inso.proyecto_final;

public interface WeaponComponent {
    public Double getDamage();
}
