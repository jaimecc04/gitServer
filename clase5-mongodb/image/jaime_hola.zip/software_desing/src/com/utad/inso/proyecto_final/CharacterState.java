package com.utad.inso.proyecto_final;

public interface CharacterState {
    public void process();
}
