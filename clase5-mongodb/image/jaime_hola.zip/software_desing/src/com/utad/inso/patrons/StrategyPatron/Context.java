package com.utad.inso.patrons.StrategyPatron;

public class Context {

    protected Strategy strategy;

    public Context(Strategy strategy) {
        this.strategy = strategy;
    }

    public void setStrategy(Strategy strategy) {
        this.strategy = strategy;
    }

    public void Examinar() {
        strategy.Examinar();
    }

    public void Factura() {
        strategy.Factura();
    }

    public void Resultados(){
        strategy.Resultados();
    }

}
