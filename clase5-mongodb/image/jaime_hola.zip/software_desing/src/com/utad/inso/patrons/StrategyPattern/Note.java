package com.utad.inso.patrons.StrategyPattern;

public enum Note {
    DO,RE,MI;
}
