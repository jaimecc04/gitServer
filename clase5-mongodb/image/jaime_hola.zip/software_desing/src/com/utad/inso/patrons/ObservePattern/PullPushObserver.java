package com.utad.inso.patrons.ObservePattern;

public interface PullPushObserver {
    void update(PullPushModelObservable observable, Object data);
}
