package com.utad.inso.patrons.StatePattern;

import com.utad.inso.patrons.ObservePattern.Book;
import com.utad.inso.patrons.ObservePattern.BookState;

public class LibraryLoanTest {
    public static void main(String[] args) {
        LoansLibrary library = LoansLibrary.getInstance();
        Book bookGood = new Book("Gang of four Design patterns", "Gang of four", BookState.GOOD);

        LibraryUser professor = new LibraryUser("MA", "ma@u-tad.com", UserType.PROFESSOR, true);
        LibraryUser student = new LibraryUser("Inés", "ines@live.u-tad.com", UserType.STUDENT, true);

        LibraryLoanRequestContext professorLoanRequest = new LibraryLoanRequestContext(library, bookGood, professor);
        LibraryLoanRequestContext studentLoanRequest = new LibraryLoanRequestContext(library, bookGood, student);

        library.processLibraryLoan(professorLoanRequest);
        library.processLibraryLoan(studentLoanRequest);

        library.processLibraryLoan(professorLoanRequest);
        library.processLibraryLoan(studentLoanRequest);

        library.returnBook(bookGood, studentLoanRequest);
        library.returnBook(bookGood, professorLoanRequest);
    }
}

