package com.utad.inso.proyecto_final;

public class ConcreteFrozenState implements CharacterState {

    private Character       character;

    ConcreteFrozenState(Character character) {
        this.character = character;
    }

    public void process() {
        if(this.character.getHealth() > 0) {
            this.unfreeze();
        } else {
            this.die();
        }
    }

    public void die() {
        this.character.setState(this.character.getDeadState());
    }

    public void freeze() {
        System.out.println("ERROR - El personaje ya está congelado");
    }

    public void unfreeze() {
        this.character.setState(this.character.getAliveState());
    }
}
