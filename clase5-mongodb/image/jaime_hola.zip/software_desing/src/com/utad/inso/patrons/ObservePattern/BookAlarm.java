package com.utad.inso.patrons.ObservePattern;

import java.util.ArrayList;
import java.util.List;

public class BookAlarm implements PullPushModelObservable {
    private List<PullPushObserver> observers;
    private Book book;

    public BookAlarm() {
        this.observers = new ArrayList<>();
    }

    @Override
    public void attach(PullPushObserver observer) {
        observers.add(observer);
    }

    @Override
    public void detach(PullPushObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (PullPushObserver observer : observers) {
            observer.update(this, book);
        }
    }

    public void setBook(Book book) {
        this.book = book;
        notifyObservers();
    }
}