package com.utad.inso.proyecto_final;

public class ConcreteDeadState implements CharacterState {

    private Character       character;

    ConcreteDeadState(Character character) {
        this.character = character;
    }
    public void process() {
        System.out.println("ERROR - El personaje está muerto");
    }

    public void die() {
        System.out.println("ERROR - El personaje ya está muerto");
    }

    public void freeze() {
        System.out.println("ERROR - El personaje está muerto");
    }

    public void unfreeze() {
        System.out.println("ERROR - El personaje no está congelado");
    }
}
