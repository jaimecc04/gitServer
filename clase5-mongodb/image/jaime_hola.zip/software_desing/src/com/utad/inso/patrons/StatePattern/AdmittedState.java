package com.utad.inso.patrons.StatePattern;

public class AdmittedState implements LoanState {
    @Override
    public void admit(LibraryLoanRequestContext context) {
        // Ya está admitido
        System.out.println("La solicitud ya ha sido admitida");
    }

    @Override
    public void pickUp(LibraryLoanRequestContext context) {
        // Implementar la lógica para recoger el libro
        context.setState(new CollectedState());
    }

    @Override
    public void returnBook(LibraryLoanRequestContext context) {
        // No se puede devolver sin estar cursada
        System.out.println("El libro no ha sido recogido todavía");
    }

    @Override
    public void reject(LibraryLoanRequestContext context) {
        context.setState(new RejectedState());
    }
}
