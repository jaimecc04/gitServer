package com.utad.inso.patrons.CamelTextFormatter;

public interface TextFormatter {
    public void format(String text);
}
