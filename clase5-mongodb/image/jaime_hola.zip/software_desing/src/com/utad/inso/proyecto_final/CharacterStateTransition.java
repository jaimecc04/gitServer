package com.utad.inso.proyecto_final;

public interface CharacterStateTransition extends CharacterState {

    public void freeze();
    public void unfreeze();
    public void die();
}
