package com.utad.inso.patrons.DecoratorPattern;

public interface RewardComponent {
    public String getDescription();
}
