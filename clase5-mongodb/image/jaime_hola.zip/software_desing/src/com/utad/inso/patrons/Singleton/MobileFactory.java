package com.utad.inso.patrons.Singleton;
/**
 * Interface de factoría
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public interface MobileFactory {
	public Mobile createMobile();
}
