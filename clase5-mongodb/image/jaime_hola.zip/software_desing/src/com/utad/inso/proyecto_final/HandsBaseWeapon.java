package com.utad.inso.proyecto_final;

public class HandsBaseWeapon implements WeaponComponent {


    public Double getDamage() {
        return 20.0;
    }

    public String toString() {
        return "Puño ";
    }
}
