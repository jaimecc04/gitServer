package com.utad.inso.patrons.DecoratorPattern;

public class AbstracRewardComponentDecorator implements RewardComponentDecorator {
    protected RewardComponent rewardComponent;

    public AbstracRewardComponentDecorator(RewardComponent rewardComponent) {
        super();
        this.rewardComponent = rewardComponent;
    }

    @Override
    public String getDescription() {
        return this.rewardComponent.getDescription() + this.toString();
    }

    public RewardComponent getRewardComponent() {
        return this.rewardComponent;
    }
}

