package com.utad.inso.proyecto_final;

public class KatanaBaseWeapon implements WeaponComponent {


    public KatanaBaseWeapon() {
    }

    public Double getDamage() {
        return 100.0;
    }

    public String toString() {
        return "Katana ";
    }
}
