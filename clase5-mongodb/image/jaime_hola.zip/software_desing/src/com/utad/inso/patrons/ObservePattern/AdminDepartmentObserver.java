package com.utad.inso.patrons.ObservePattern;

public class AdminDepartmentObserver implements PullPushObserver {
    @Override
    public void update(PullPushModelObservable observable, Object data) {
        if (data instanceof Book) {
            Book book = (Book) data;
            System.out.println("[AdminDepartmentObserver Push] se ha devuelto el libro en mal estado");
            System.out.println(book);
        }
    }
}
