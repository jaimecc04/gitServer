package com.utad.inso.proyecto_final;

public class NoArmorConcreteStrategy implements ArmorAbstractStrategy {
    public Integer getProtection() {
        return 0;
    }

    public String toString() {
        return "Sin armadura";
    }
}
