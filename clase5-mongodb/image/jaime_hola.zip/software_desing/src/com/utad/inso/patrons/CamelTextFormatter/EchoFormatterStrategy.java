package com.utad.inso.patrons.CamelTextFormatter;

public class EchoFormatterStrategy {
}
