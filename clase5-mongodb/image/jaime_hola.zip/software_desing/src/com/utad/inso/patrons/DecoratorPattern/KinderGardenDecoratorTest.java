package com.utad.inso.patrons.DecoratorPattern;

import com.utad.inso.patrons.ObservePattern.Book;
import com.utad.inso.patrons.ObservePattern.BookState;

public class KinderGardenDecoratorTest {
    public static void main(String[] args) {
        KinderGarden kinderGarden = new KinderGarden();
        Book book = new Book("Desing patterns", "Gang of four", BookState.GOOD);

        KinderGardenBaby ines = new KinderGardenBaby("Ines", 1);
        KinderGardenBaby kike = new KinderGardenBaby("Enrique", 2, "Kike");

        KinderGarden.getBabies().add(ines);
        KinderGarden.getBabies().add(kike);
        kinderGarden.checkBabies();

        ines.setRewardComponent((new CertificateRewardComponentDecorator(ines.getRewardComponent())));
        kinderGarden.checkBabies();
        ines.setRewardComponent(new BookRewardComponentDecorator(ines.getRewardComponent(), book));
        kinderGarden.checkBabies();

        if (ines.getRewardComponent() instanceof BookRewardComponentDecorator) {
            System.out.println(ines.getName() + " tiene el libro: " +
                    ((BookRewardComponentDecorator) ines.getRewardComponent()).getBook().getTitle());
        }
    }
}
