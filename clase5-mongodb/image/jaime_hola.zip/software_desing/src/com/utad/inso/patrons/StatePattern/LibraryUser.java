package com.utad.inso.patrons.StatePattern;

public class LibraryUser {
    private String name;
    private String address;
    private UserType userType;
    private Boolean activeAccount;

    public LibraryUser(String name, String address, UserType userType, Boolean activeAccount) {
        this.name = name;
        this.address = address;
        this.userType = userType;
        this.activeAccount = activeAccount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void update(String message) {
        System.out.println("Notification to user: " + name + ", " + message);
    }

    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public Boolean isActiveAccount() {
        return activeAccount;
    }

    public void setActiveAccount(Boolean activeAccount) {
        this.activeAccount = activeAccount;
    }
}
