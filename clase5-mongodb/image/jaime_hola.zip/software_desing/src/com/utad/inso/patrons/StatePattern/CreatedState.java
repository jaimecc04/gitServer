package com.utad.inso.patrons.StatePattern;

public class CreatedState implements LoanState {
    @Override
    public void admit(LibraryLoanRequestContext context) {
        // Implementar la lógica para admitir la solicitud
        context.setState(new AdmittedState());
    }

    @Override
    public void pickUp(LibraryLoanRequestContext context) {
        // No se puede recoger sin estar admitido
        System.out.println("La solicitud debe ser admitida primero");
    }

    @Override
    public void returnBook(LibraryLoanRequestContext context) {
        // No se puede devolver sin estar cursada
        System.out.println("El libro no ha sido recogido todavía");
    }

    @Override
    public void reject(LibraryLoanRequestContext context) {
        context.setState(new RejectedState());
    }
}
