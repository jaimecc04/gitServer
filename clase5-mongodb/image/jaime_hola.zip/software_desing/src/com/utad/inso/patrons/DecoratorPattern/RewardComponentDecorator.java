package com.utad.inso.patrons.DecoratorPattern;

public interface RewardComponentDecorator extends RewardComponent {
    public RewardComponent getRewardComponent();
}
