package com.utad.inso.patrons.StrategyPattern;

public class PiezaDeJuego {

}
