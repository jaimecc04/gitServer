package com.utad.inso.patrons.Singleton;
/**
 * Clase test para obtener una instancia de objeto Mobile
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public class MobileClientTest {
	public static void main(String[] args) {
		Mobile phone = MobileFactoryManager.getInstance().createMobile();
		System.out.println(phone.getBrand());
	}
}
