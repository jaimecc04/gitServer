package com.utad.inso.patrons.StrategyPattern;

public class FormaDeJuego {
    public void muestraFigura() {
        System.out.println("Mostrando forma");
    }

    public static void main(String[] args) {
        FormaDeJuego figura = new FormaDeJuego();

        figura.muestraFigura();
    }
}
