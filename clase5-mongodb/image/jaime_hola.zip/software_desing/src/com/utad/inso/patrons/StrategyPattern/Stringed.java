package com.utad.inso.patrons.StrategyPattern;

public class Stringed extends Instrument implements ElectricSound {
    public void play(Note note) {
        System.out.println("Stringed.play(): " + note);
    }

    public String what() {
        return "Stringed";
    }

    public void electricPlay(Note note) {
        System.out.println("ElectricSound.Stringed.play(): " + note);
    }
}
