package com.utad.inso.patrons.Singleton;
/**
 * Interface de producto
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public interface Mobile {
	public String getBrand();
}

