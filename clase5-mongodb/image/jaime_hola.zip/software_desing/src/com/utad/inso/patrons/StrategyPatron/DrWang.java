package com.utad.inso.patrons.StrategyPatron;

public class DrWang implements Strategy {

    public void Examinar() {
        System.out.println("Examinar a los niños (Dr. Wang)");
    }

    public void Factura() {
        System.out.println("Enviar a los padres la factura (Dr. Wang)");
    }

    public void Resultados(){
        System.out.println("Enviando a los padres el resultado de el examen (Dr. Wang)");
    }
}
