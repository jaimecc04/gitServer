package com.utad.inso.patrons.StrategyPatron;

public interface Strategy {
    public void Examinar();

    public void Factura();

    public void Resultados();
}
