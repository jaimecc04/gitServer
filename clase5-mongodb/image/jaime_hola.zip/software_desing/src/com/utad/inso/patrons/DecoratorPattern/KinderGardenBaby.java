package com.utad.inso.patrons.DecoratorPattern;

public class KinderGardenBaby extends Baby {
    private RewardComponent rewardComponent;

    public KinderGardenBaby(String name, Integer age, String nickname){
        this(name, age, nickname, new StickerRewardComponent(name));
    }

    public KinderGardenBaby(String name, Integer age){
        this(name, age, name, new StickerRewardComponent(name));
    }

    public KinderGardenBaby(String name, Integer age, String nickname, StickerRewardComponent rewardComponent) {
        super(name, age, nickname);
        this.rewardComponent = rewardComponent;
    }

    public RewardComponent getRewardComponent(){
        return this.rewardComponent;
    }

    public void setRewardComponent(RewardComponent rewardComponent){
        this.rewardComponent = rewardComponent;
    }

    @Override
    public String toString() {
        return "KinderGardenBaby [name=" + this.name + ", age=" + this.age +
                ", rewardComponent=" + this.rewardComponent.getDescription() + "]";
    }
}
