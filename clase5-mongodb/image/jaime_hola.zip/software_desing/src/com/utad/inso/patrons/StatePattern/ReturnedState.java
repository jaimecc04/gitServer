package com.utad.inso.patrons.StatePattern;

import com.utad.inso.patrons.ObservePattern.BookState;

import java.time.LocalDate;

public class ReturnedState implements LoanState {
    @Override
    public void admit(LibraryLoanRequestContext context) {
        System.out.println("La solicitud ya ha sido devuelta");
    }

    @Override
    public void pickUp(LibraryLoanRequestContext context) {
        System.out.println("La solicitud ya ha sido devuelta");
    }

    @Override
    public void returnBook(LibraryLoanRequestContext context) {
        System.out.println("Procesando devolución del libro...");

        if (context.getPickupDate() != null && LocalDate.now().isAfter(context.getPickupDate())) {
            System.out.println("El libro ha sido devuelto.");

            context.getBook().setBookState(BookState.GOOD);
        } else {
            System.out.println("El libro no ha sido recogido todavía.");
        }

        LibraryUser user = context.getLibraryUser();
        System.out.println("Notification to user: " + user.getName() + ", library loan returned on "
                + LocalDate.now() + ", Book " + context.getBook());
    }

    @Override
    public void reject(LibraryLoanRequestContext context) {
        System.out.println("La solicitud ya ha sido devuelta");
    }
}
