package com.utad.inso.patrons.Singleton;
/**
 * Manager de factoría singleton
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public class MobileFactoryManager {
	private static MobileFactoryManager mobileFactoryManager = 
			new MobileFactoryManager(new IphoneFactory());
	private MobileFactoryManager(MobileFactory mobileFactory){
		this.mobileFactory = mobileFactory;
	}
	private MobileFactory mobileFactory;
	public static MobileFactoryManager getInstance() {
		return mobileFactoryManager;
	}
	public static void setMobileFactoryManager(MobileFactoryManager mobileFactoryManager) {
		MobileFactoryManager.mobileFactoryManager = mobileFactoryManager;
	}
	public MobileFactory getMobileFactory() {
		return mobileFactory;
	}
	public void setMobileFactory(MobileFactory mobileFactory) {
		this.mobileFactory = mobileFactory;
	}
	public Mobile createMobile(){
		return this.mobileFactory.createMobile();
	}
}

