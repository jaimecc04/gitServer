package com.utad.inso.patrons.StatePattern;

import com.utad.inso.patrons.ObservePattern.Book;
import com.utad.inso.patrons.ObservePattern.BookState;

import java.time.LocalDate;

public class LoansLibrary {
    private static LoansLibrary instance;

    private LoansLibrary() {
    }

    public static LoansLibrary getInstance() {
        if (instance == null) {
            instance = new LoansLibrary();
        }
        return instance;
    }

    public void processLibraryLoan(LibraryLoanRequestContext libraryLoanRequestContext) {
        System.out.println("Procesando solicitud de préstamo...");

        libraryLoanRequestContext.getCurrentState().admit(libraryLoanRequestContext);

        LocalDate pickupDate = LocalDate.now().plusDays(libraryLoanRequestContext.getLibraryUser().getUserType().getLoanDays());
        libraryLoanRequestContext.setPickupDate(pickupDate);

        LocalDate dueDate = libraryLoanRequestContext.getPickupDate().plusDays(5);
        libraryLoanRequestContext.getLibraryUser().update("library loan admitted on " + LocalDate.now() + ", due date to pickup " + dueDate);
    }


    public void returnBook(Book book, LibraryLoanRequestContext libraryLoanRequestContext) {
        System.out.println("Procesando devolución del libro...");

        libraryLoanRequestContext.getCurrentState().returnBook(libraryLoanRequestContext);

        book.setBookState(BookState.GOOD);

        LibraryUser user = libraryLoanRequestContext.getLibraryUser();
        System.out.println("Notification to user: " + user.getName() + ", library loan returned on "
                + LocalDate.now() + ", Book " + book);
    }
}
