package com.utad.inso.patrons.CamelTextFormatter;

public class CamelTextFormatter extends TestStrategyPattern {
}
