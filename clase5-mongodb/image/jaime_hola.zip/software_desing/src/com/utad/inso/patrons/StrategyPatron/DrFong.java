package com.utad.inso.patrons.StrategyPatron;

public class DrFong implements Strategy{

    public void Examinar() {
        System.out.println("Examinar a los niños (Dr. Fong)");
    }

    public void Factura() {
        System.out.println("Enviar a los padres la factura y el resultado del examen (Dr. Fong)");
    }

    public void Resultados(){
        System.out.println("Enviando a los padres el resultado de el examen (Dr. Fong)");
    }
}
