package com.utad.inso.patrons.StrategyAreas;

import java.util. Scanner;
public class CalculaArea {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        CircleAreaStrategy circleAreaStrategy = new CircleAreaStrategy();
        SquareAreaStrategy squareAreaStrategy = new SquareAreaStrategy();

        ContextAreaStrategy contextAreaStrategy = new ContextAreaStrategy(circleAreaStrategy);

        System.out.println ("Elige el área que desea calcular:");
        System.out.println("1. Cuadrado 2.Círculo");
        int n = sc.nextInt();
        if (n == 1) {
            System.out.println("lado del cuadrado (cms) :");
            int lado = sc.nextInt();
            contextAreaStrategy.setAreaStrategy(squareAreaStrategy);
            System.out.println(contextAreaStrategy.area(lado));
        } else if (n == 2) {
            System.out.println("Radio del círculo (cms) :");
            int radio = sc.nextInt();
            contextAreaStrategy.setAreaStrategy(circleAreaStrategy);
            System.out.println(contextAreaStrategy.area(radio));
        } else {
            System.out.println("Argumento no válido.");
            sc.close();
        }
    }
}