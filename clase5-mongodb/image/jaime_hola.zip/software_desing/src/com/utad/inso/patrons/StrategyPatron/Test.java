package com.utad.inso.patrons.StrategyPatron;

public class Test {
    public static void main(String[] args) {
        Strategy strategyFong = new DrFong();
        Strategy strategyWang = new DrWang();

        Context context = new Context(strategyFong);
        context.Examinar();

        context.setStrategy(strategyWang);
        context.Factura();
    }
}
