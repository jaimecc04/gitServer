package com.utad.inso.patrons.StrategyPattern;

public class Brass extends Wind implements ElectricSound {
    public void play(Note note) {
        System.out.println("Brass.play(): " + note);

    }

    public String what() {
        return "Brass";
    }

    public void electricPlay(Note note) {
        System.out.println("ElectricSound.Brass.play(): " + note);
    }
}
