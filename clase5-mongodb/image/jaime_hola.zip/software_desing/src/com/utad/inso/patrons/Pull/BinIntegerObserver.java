package com.utad.inso.patrons.Pull;
/**
 * Observador Pull que muestra un valor en base decimal en base binaria
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public class BinIntegerObserver implements PullObserver {

	private ConcreteIntegerSubject concreteIntegerSubject;
	

	public BinIntegerObserver(ConcreteIntegerSubject concreteIntegerSubject)  {
		super();
		this.concreteIntegerSubject = concreteIntegerSubject;
	}

	public void update() {
		System.out.println( "Binary Integer as String: " + 
				Integer.toBinaryString( this.concreteIntegerSubject.getState()) );
		
	}

}
