package com.utad.inso.patrons.StatePattern;

public class ConsoleNotificationStrategy implements NotificationStrategy {
    public void notifyUser(LibraryUser user, String message) {
        System.out.println("Notification to user: " + user.getName() + ", " + message);
    }
}
