package com.utad.inso.patrons.StrategyAreas;

public class CircleAreaStrategy implements AreaStrategy {
    @Override
    public double area(int x) {
        return Math.PI * x * x;
    }
}
