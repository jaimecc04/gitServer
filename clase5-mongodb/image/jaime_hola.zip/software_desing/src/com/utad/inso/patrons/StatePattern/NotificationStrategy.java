package com.utad.inso.patrons.StatePattern;

public interface NotificationStrategy {
    void notifyUser(LibraryUser user, String message);
}
