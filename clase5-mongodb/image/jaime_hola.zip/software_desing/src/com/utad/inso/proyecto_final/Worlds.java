package com.utad.inso.proyecto_final;

public enum Worlds {
    DESERT, HELL, GLACIAL;
}
