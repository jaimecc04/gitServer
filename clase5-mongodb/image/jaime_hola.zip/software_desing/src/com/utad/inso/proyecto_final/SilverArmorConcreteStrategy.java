package com.utad.inso.proyecto_final;

public class SilverArmorConcreteStrategy implements ArmorAbstractStrategy {

    public Integer getProtection() {
        return 25;
    }

    public String toString() {
        return "Armadura de plata";
    }
}
