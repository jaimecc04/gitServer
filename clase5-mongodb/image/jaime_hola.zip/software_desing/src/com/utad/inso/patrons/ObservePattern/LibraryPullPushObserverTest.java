package com.utad.inso.patrons.ObservePattern;

public class LibraryPullPushObserverTest {
    public static void main(String[] args) {
        StockDepartmentObserver stockObserver = new StockDepartmentObserver();
        AdminDepartmentObserver adminObserver = new AdminDepartmentObserver();
        ComprasDepartmentObserver comprasObserver = new ComprasDepartmentObserver();

        Library library = new Library();

        library.bookAlarm.attach(stockObserver);
        library.bookAlarm.attach(adminObserver);
        library.bookAlarm.attach(comprasObserver);

        System.out.println("Alarma notifica bajo protocolo PULL-PUSH");
        Book bookBad = new Book("Programar sin patrones", "desconocido", BookState.BAD);
        Book bookGood = new Book("Gang of four Design patterns", "Erich Gamma, Richard Helm",
                BookState.GOOD);

        library.returnBook(bookGood);
        library.returnBook(bookBad);

        System.out.println("Alarma vuelve a notificar bajo protocolo PULL-PUSH");
        library.bookAlarm.detach(comprasObserver);

        Book otherBookBad = new Book("Programar sin pensar", "desconocido", BookState.BAD);
        library.returnBook(otherBookBad);

    }
}

