package com.utad.inso.patrons.StatePattern;

public class CollectedState implements LoanState {
    @Override
    public void admit(LibraryLoanRequestContext context) {
        System.out.println("La solicitud ya ha sido admitida.");
    }

    @Override
    public void pickUp(LibraryLoanRequestContext context) {
        context.setState(new ReturnedState());
        System.out.println("El libro ha sido devuelto.");
    }

    @Override
    public void returnBook(LibraryLoanRequestContext context) {
        System.out.println("El libro ya ha sido devuelto.");
    }

    @Override
    public void reject(LibraryLoanRequestContext context) {
        System.out.println("No se puede rechazar una solicitud ya admitida.");
    }
}

