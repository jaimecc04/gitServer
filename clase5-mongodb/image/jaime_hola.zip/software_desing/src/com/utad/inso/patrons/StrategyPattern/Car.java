package com.utad.inso.patrons.StrategyPattern;

public class Car {

    private String marca;
    private String modelo;
    private String color;
    private Engine motor;

    public Car(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public void encender() {
        this.motor = new Engine("Eléctrico");
        this.motor.encender(); // Delegación por agregación
        this.motor = null;
    }

    public void avanzar() {
        System.out.println("Avanzando " + this.toString());
    }

    public String toString() {
        return this.getMarca() + " " + this.getModelo() + " " + this.getColor();
    }

    public static void main(String[] args) {
        ElectricCar tesla = new ElectricCar("Tesla", "Model3", "rojo");
        tesla.encender();
        tesla.avanzar();
    }

}
