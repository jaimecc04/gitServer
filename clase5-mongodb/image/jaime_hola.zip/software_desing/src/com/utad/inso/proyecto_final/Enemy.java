package com.utad.inso.proyecto_final;

public interface Enemy extends Character {
    public void decideAction();
}
