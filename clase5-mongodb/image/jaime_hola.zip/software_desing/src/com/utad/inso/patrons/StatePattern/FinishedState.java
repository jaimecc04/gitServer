package com.utad.inso.patrons.StatePattern;

public class FinishedState implements LoanState {
    @Override
    public void admit(LibraryLoanRequestContext context) {
        System.out.println("La solicitud ya ha sido finalizada.");
    }

    @Override
    public void pickUp(LibraryLoanRequestContext context) {
        System.out.println("El libro ya ha sido recogido.");
    }

    @Override
    public void returnBook(LibraryLoanRequestContext context) {
        System.out.println("El libro ya ha sido devuelto.");
    }

    @Override
    public void reject(LibraryLoanRequestContext context) {
        System.out.println("La solicitud ya ha sido finalizada.");
    }
}

