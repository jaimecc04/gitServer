package com.utad.inso.patrons.DecoratorPattern;

import com.utad.inso.patrons.ObservePattern.Book;

public class BookRewardComponentDecorator extends AbstracRewardComponentDecorator{
    private Book book;

    public BookRewardComponentDecorator(RewardComponent rewardComponent, Book book){
        super(rewardComponent);
        this.book = book;
    }

    public Book getBook(){
        return  this.book;
    }

    public void setBook(Book book){
        this.book = book;
    }

    public String toString(){
        return " es niño de la semana con libro: " + this.book;
    }
}

