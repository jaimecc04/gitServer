package com.utad.inso.proyecto_final;

public interface WeaponDecoratorComponent extends WeaponComponent {
    public WeaponComponent getDecorated();
    public void setDecorated(WeaponComponent decorated);
}
