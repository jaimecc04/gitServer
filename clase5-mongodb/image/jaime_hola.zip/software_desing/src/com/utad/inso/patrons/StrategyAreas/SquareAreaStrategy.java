package com.utad.inso.patrons.StrategyAreas;

public class SquareAreaStrategy implements AreaStrategy {
    @Override
    public double area(int x) {
        return x * x;
    }
}
