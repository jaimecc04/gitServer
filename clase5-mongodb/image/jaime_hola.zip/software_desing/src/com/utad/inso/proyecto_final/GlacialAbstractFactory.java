package com.utad.inso.proyecto_final;

public class GlacialAbstractFactory implements EnemyAbstractFactory {

    public IceSoldier createIceSoldier() {
        return new GlacialIceSoldier();
    }

    public InfernalDragon createInfernalDragon() {
        return new GlacialInfernalDragon();
    }
    public SandGiant createSandGiant() {
        return new GlacialSandGiant();
    }
}
