package com.utad.inso.patrons.DecoratorPattern;

public class Baby {
    protected String name;
    protected Integer age;
    protected String nickname;

    public Baby(String name, Integer age, String nickname) {
        super();
        this.name = name;
        this.age = age;
        this.nickname = nickname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
}
