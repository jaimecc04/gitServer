package com.utad.inso.proyecto_final;

public interface Character {
    public void attack(Character target);
    public void takeDamage(Double damage);
    public WeaponComponent getWeapon();
    public void setWeapon(WeaponComponent weapon);

    public ArmorAbstractStrategy getArmor();
    public void setArmor(ArmorAbstractStrategy armor);
    //public void useItem(Item item);
    public Double getHealth();
    public CharacterState getState();
    public ConcreteAliveState getAliveState();
    public ConcreteDeadState getDeadState();
    public ConcreteFrozenState getFrozenState();
    public void setState(CharacterState state);
    public Double getStrength();
    public Double getPrecision();

}
