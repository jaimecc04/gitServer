package com.utad.inso.proyecto_final;

import java.util.Scanner;

public class Player implements Character {

    private String                          name;
    private Double                          health;
    private ArmorAbstractStrategy           armor;
    private WeaponComponent                 weapon;
    private CharacterState                  characterState;
    private Double                          strength;
    private Double                          precision;
    private Boolean                         healed;

    private ConcreteAliveState              concreteAliveState;
    private ConcreteDeadState               concreteDeadState;
    private ConcreteFrozenState             concreteFrozenState;


    public Player(String name, Double health, Double strength, Double precision) {
        this.name = name;
        this.health = health;
        this.weapon = new FireDecoratorWeapon(new KatanaBaseWeapon());
        this.armor = new NoArmorConcreteStrategy();
        this.strength = strength;
        this.precision = precision;
        this.healed = false;

        this.concreteAliveState = new ConcreteAliveState(this);
        this.concreteDeadState = new ConcreteDeadState(this);
        this.concreteFrozenState = new ConcreteFrozenState(this);

        this.characterState = this.concreteAliveState;
    }

    public String getName() {
        return name;
    }


    public Double getStrength() {
        return strength;
    }

    public Double getPrecision() {
        return precision;
    }

    public ConcreteFrozenState getFrozenState() {
        return this.concreteFrozenState;
    }

    public ConcreteAliveState getAliveState() {
        return this.concreteAliveState;
    }

    public ConcreteDeadState getDeadState() {
        return this.concreteDeadState;
    }

    public Double getHealth() {
        return this.health;
    }

    public ArmorAbstractStrategy getArmor() {
        return this.armor;
    }

    public void setArmor(ArmorAbstractStrategy armor) {
        this.armor = armor;
    }

    public WeaponComponent getWeapon() {
        return this.weapon;
    }

    public void setWeapon(WeaponComponent weapon) {
        this.weapon = weapon;
    }

    public void attack(Character target) {

        if(this.getState() instanceof ConcreteFrozenState) {
            System.out.println(name + " está congelado y no puede atacar");
            this.getState().process();
        } else {
            Double dano = AttackCalculator.getInstance().returnAttack(this);
            target.takeDamage(dano);
            System.out.println(this.name + " ataca con " + this.getWeapon() + " [-" + dano + "HP]");
        }
    }

    public void takeDamage(Double damage) {

        if(damage < 0) {
            damage *= -1;
            this.health -= damage;
            this.characterState.process();
        } else {
            this.health -= damage;
        }

        if(this.health <= 0){
            this.characterState.process();
        }
    }


    public CharacterState getState() {
        return this.characterState;
    }

    public void setState(CharacterState state) {
        this.characterState = state;
    }

    public void heal() {
        if(!healed) {
            this.health += 150;
            this.healed = true;
            System.out.println(name + " se ha curado");
        } else {
            System.out.println(name + " ya se había curado antes por lo que no se puede curar más");
        }
    }

    public String toString() {
        return name + " [" + this.health + "HP]";
    }
}
