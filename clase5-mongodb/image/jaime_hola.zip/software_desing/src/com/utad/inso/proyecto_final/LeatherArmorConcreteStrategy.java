package com.utad.inso.proyecto_final;

public class LeatherArmorConcreteStrategy implements ArmorAbstractStrategy {

    public Integer getProtection() {
        return 10;
    }

    public String toString() {
        return "Armadura de cuero";
    }
}
