package com.utad.inso.proyecto_final;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

public class GameController {
    private static GameController           gameController = new GameController();
    private Player                          player;
    private AttackCalculator                attackCalculator;
    private Worlds                          currentLevel;
    private EnemyAbstractFactory            enemyAbstractFactory;
    private ArrayList<Enemy>                liveEnemies;
    private Random                          randGenerator;
    private Scanner                         sc;
    private GameController() {
        super();
        this.attackCalculator = AttackCalculator.getInstance();
        this.currentLevel = Worlds.DESERT;
        this.enemyAbstractFactory = new DesertAbstractFactory();
        this.liveEnemies = new ArrayList<Enemy>();
        this.randGenerator = new Random();
        this.sc = new Scanner(System.in);
    }

    private void createPlayer() {
        Double total_points = 300.0;
        Double strength = 0.0;
        Double precision = 0.0;
        String name;
        System.out.println("Introduce el nombre del jugador: ");

        name = this.sc.nextLine();

        System.out.println("Introduce la fuerza del personaje " + "[" + total_points + " puntos restantes]: ");
        strength = this.sc.nextDouble();
        total_points -= strength;

        System.out.println("Introduce la precisión del personaje " + "[" + total_points + " puntos restantes]: ");
        precision = this.sc.nextDouble();
        total_points -= precision;

        System.out.println("La resistencia del personaje es de: " + total_points + " puntos");

        if(strength <= 0.0 || precision <= 0.0 || total_points <= 0.0) {
            System.out.println("Los atributos deben ser todos positivos");
            System.exit(0);
        }

        this.player = new Player(name, total_points, strength, precision);
        this.playerChooseWeaponArmor();

    }

    private void playerChooseWeaponArmor() {
        Integer decision = 0;

        System.out.println("Elige la armadura: ");
        System.out.println("1. Sin armadura");
        System.out.println("2. Armadura de cuero");
        System.out.println("3. Armadura de oro");
        System.out.println("4. Armadura de plata");

        decision = sc.nextInt();

        switch(decision) {
            case 1:
                player.setArmor(new NoArmorConcreteStrategy());
                break;
            case 2:
                player.setArmor(new LeatherArmorConcreteStrategy());
                break;
            case 3:
                player.setArmor(new GoldArmorConcreteStrategy());
                break;
            case 4:
                player.setArmor(new SilverArmorConcreteStrategy());
                break;
            default:
                System.out.println("Esa armadura no existe");
                System.exit(0);
        }

        System.out.println("Elige ahora el arma base");
        System.out.println("1. Puño");
        System.out.println("2. Katana");

        decision = sc.nextInt();
        if(decision == 1) {
            player.setWeapon(new HandsBaseWeapon());
        } else if(decision == 2) {
            player.setWeapon(new KatanaBaseWeapon());
        } else {
            System.out.println("Ese arma base no existe");
            System.exit(0);
        }

        System.out.println("Elige ahora un decorador para tu arma");
        System.out.println("1. Fuego");
        System.out.println("2. Veneno");

        decision = sc.nextInt();
        if(decision == 1) {
            player.setWeapon(new FireDecoratorWeapon(player.getWeapon()));
        } else if(decision == 2) {
            player.setWeapon(new VenomDecoratorWeapon(player.getWeapon()));
        } else {
            System.out.println("Ese decorador no existe");
            System.exit(0);
        }
    }

    public Worlds getCurrentLevel() {
        return currentLevel;
    }

    public static GameController getInstance() {
        return gameController;
    }

    private void runLevel(Worlds level) {

        System.out.println("NUEVO MUNDO: " + level);
        System.out.println("__________________________________");

        this.generateEnemies(this.currentLevel);

        while(!this.liveEnemies.isEmpty()) {
            describeCharacter(this.liveEnemies.get(0));
            handleRound(player, this.liveEnemies.get(0));
        }
        System.out.println("MUNDO SUPERADO\n");

    }

    private void playerDecide(Character enemy) {
        System.out.println("TU TURNO " + this.player.getName());
        System.out.println("Elige de entre las siguientes opciones:");
        System.out.println("1. Atacar");
        System.out.println("2. Curar");
        System.out.println("3. Huir");
        System.out.println("4. Nada");
        System.out.println("5. Retirada");
        int decision = sc.nextInt();

        switch(decision) {
            case 1:
                this.player.attack(enemy);
                break;
            case 2:
                this.player.heal();
                break;
            case 3:
                if(randGenerator.nextInt(300) < 300 - player.getPrecision()) {
                    this.liveEnemies.remove(0);
                    System.out.println("Has conseguido huir");
                } else {
                    System.out.println("No has conseguido huir");
                }
                break;
            case 4:
                System.out.println("Elegiste saltar tu turno");
                break;
            case 5:
                System.out.println("Te has retirado");
                System.exit(0);
        }
    }

    private void handleRound(Player player, Enemy enemy) {

        System.out.println("----- " + player + " VS " + enemy + " --------");

        if(this.randGenerator.nextInt(2) == 1) {
            this.playerDecide(enemy);
            enemy.decideAction();
        } else {
            this.playerDecide(enemy);
            enemy.decideAction();
        }

        if(player.getState() instanceof ConcreteDeadState) {
            System.out.println("El jugador " + player.getName() + " ha muerto");
            System.exit(0);
        } else if(enemy.getState() instanceof ConcreteDeadState){
            this.liveEnemies.remove(0);
        }
    }

    public Random getRandGenerator() {
        return randGenerator;
    }

    public Player getPlayer() {
        return player;
    }

    private void generateEnemies(Worlds level) {
        if(level == Worlds.HELL) {
            this.enemyAbstractFactory = new HellAbstractFactory();
        } else if(level == Worlds.GLACIAL) {
            this.enemyAbstractFactory = new GlacialAbstractFactory();
        } else {
            this.enemyAbstractFactory = new DesertAbstractFactory();
        }

        this.liveEnemies.add(this.enemyAbstractFactory.createIceSoldier());
        this.liveEnemies.add(this.enemyAbstractFactory.createSandGiant());
        this.liveEnemies.add(this.enemyAbstractFactory.createInfernalDragon());

    }

    public void start() {
        this.attackCalculator.setGameController(this);
        this.createPlayer();
        System.out.println("-----> Jugador creado: " +  this.player);
        System.out.println("--------------------------------------------------");
        System.out.println("ARMA: " + player.getWeapon());
        System.out.println("ARMADURA: " + player.getArmor());
        System.out.println("VIDA: " + player.getHealth());

        this.runLevel(this.currentLevel);
        this.currentLevel = Worlds.GLACIAL;
        this.runLevel(this.currentLevel);
        this.currentLevel = Worlds.HELL;
        this.runLevel(this.currentLevel);

        System.out.println("HAS GANADO!");

    }

    private void describeCharacter(Character character) {
        System.out.println("APARECE " + character);
        System.out.println("ARMA: " + character.getWeapon());
        System.out.println("ARMADURA: " + character.getArmor());
        System.out.println("VIDA: " + character.getHealth());
    }

}
