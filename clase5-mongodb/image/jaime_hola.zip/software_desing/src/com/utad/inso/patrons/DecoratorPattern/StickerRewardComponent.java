package com.utad.inso.patrons.DecoratorPattern;

public class StickerRewardComponent implements RewardComponent{
    private String description;

    public StickerRewardComponent(String description){
        super();
        this.description = description;
    }

    public String getDescription() {
        return this.description;
    }

    @Override
    public String toString() {
        return "StickerRewardComponent [description=" + this.description + "]";
    }
}
