package com.utad.inso.patrons.Singleton;
/**
 * Factoría de concreta
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public class IphoneFactory implements MobileFactory {
	public Mobile createMobile() {
		return new Iphone();
	}
}
