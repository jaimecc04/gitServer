package com.utad.inso.patrons.ObservePattern;

public enum BookState {
    GOOD,
    BAD
}
