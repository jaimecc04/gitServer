package com.utad.inso.proyecto_final;

public interface EnemyAbstractFactory {
    public IceSoldier createIceSoldier();
    public SandGiant createSandGiant();
    public InfernalDragon createInfernalDragon();
}
