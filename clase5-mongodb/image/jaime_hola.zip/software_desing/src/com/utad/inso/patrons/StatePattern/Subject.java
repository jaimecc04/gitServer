package com.utad.inso.patrons.StatePattern;

public interface Subject {
    void registerObserver(Object observer);
    void removeObserver(Object observer);
    void notifyObservers(String message);
}


