package com.utad.inso.patrons.Singleton;
/**
 * Clase concreta de producto
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public class SamsungMobile implements Mobile {
	public String getBrand() {
		return "Samsung";
	}
}
