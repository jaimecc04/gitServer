package com.utad.inso.patrons.StrategyPattern;

public abstract class Instrument {
    public abstract void play(Note note);
    public String what() {
        return "Instrument";
    }
}
