package com.utad.inso.patrons.StatePattern;

public enum UserType {
    STUDENT(15), PROFESSOR(10);

    private final int loanDays;

    UserType(int loanDays) {
        this.loanDays = loanDays;
    }

    public int getLoanDays() {
        return loanDays;
    }
}
