package com.utad.inso.patrons.StatePattern;

import com.utad.inso.patrons.ObservePattern.Book;

import java.time.LocalDate;

public class LibraryLoanRequestContext {
    private LoanState currentState;
    private LoansLibrary loansLibrary;
    private Book book;
    private LibraryUser libraryUser;
    private LocalDate createdDate;
    private LocalDate pickupDate;

    public LibraryLoanRequestContext(LoansLibrary loansLibrary, Book book, LibraryUser libraryUser) {
        this.loansLibrary = loansLibrary;
        this.book = book;
        this.libraryUser = libraryUser;
        this.createdDate = LocalDate.now();
        this.currentState = new CreatedState();
    }

    public void process() {
        currentState.admit(this);
    }

    public void pickUp() {
        currentState.pickUp(this);
    }

    public void returnBook() {
        currentState.returnBook(this);
    }

    public void reject() {
        currentState.reject(this);
    }

    public void setState(LoanState state) {
        this.currentState = state;
    }

    public LoanState getCurrentState() {
        return currentState;
    }

    public void setCurrentState(LoanState currentState) {
        this.currentState = currentState;
    }

    public LoansLibrary getLoansLibrary() {
        return loansLibrary;
    }

    public void setLoansLibrary(LoansLibrary loansLibrary) {
        this.loansLibrary = loansLibrary;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public LibraryUser getLibraryUser() {
        return libraryUser;
    }

    public void setLibraryUser(LibraryUser libraryUser) {
        this.libraryUser = libraryUser;
    }

    public LocalDate getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDate createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDate getPickupDate() {
        return pickupDate;
    }

    public void setPickupDate(LocalDate pickupDate) {
        this.pickupDate = pickupDate;
    }
}
