package com.utad.inso.patrons.CamelTextFormatter;

public class TestStrategyPattern {
    public static void main(String[] args) {
        TextFormatter formatter = new CapTextFormatter();
        TextEditor editor = new TextEditor(formatter);
        editor.format("Testing text in caps formatter");

        formatter = new LowerTextFormatter();
        editor.setTextFormatter(formatter);
        editor.format("Testing text in lower formatter");
    }
}
