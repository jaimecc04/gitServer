package com.utad.inso.patrons.Pull;
/**
 * Interface de un observador que aplica protocolo Pull 
 *
 * @author  Miguel Ángel Mesas Uzal
 * fecha:   2022-2023
 *
 */
public interface PullObserver {
	public void update();
}
